create database Incubator;
use Incubator;

/* I want to create a table named Tract*/

Create table Tract(
id int not null,
tract_id int,
Name varchar(255),
primary key (tract_id)
);

insert into tract values(1,	101,	'SQL');
insert into tract values(2,	201,	'Python');
insert into tract values(3,	301,	'PowerBI');

 select * from tract;

 /* create table instructors*/

Create table Instructors_Name(
id int not null,
tract_id int,
Name varchar(255),
primary key (tract_id)
);
insert into Instructors_Name values(1,	101,	'Ifeoma okafor');
insert into Instructors_Name values(2,	201,	'Segun Yemi');
insert into Instructors_Name values(3,	301,	'Salaudeen Ibrahim');
 
select * from instructors_name;

/* I want to create a table named Student_tract*/
Create table Student_tract(
id int not null ,
Student_Name varchar(255),
tract int not null ,
primary key (id)
);

/*Inserting rows into the table tract*/

insert into Student_tract values(1,	'Tomisin Falode', 201);
insert into Student_tract values(2,	'Akinmutimi Gbemiro', 201);
insert into Student_tract values(3,	'Adedara David', 201);
insert into Student_tract values(4,	'Blessing Okeke', 201);
insert into Student_tract values(5,	'Janet Olasore', 201);
insert into Student_tract values(6, 'Adeyeye Seyi', 201);
insert into Student_tract values(7,	'Orhorhamreru Moronke Rachael', 201);
insert into Student_tract values(8,	'Ayeni funmilayo', 201);
insert into Student_tract values(9,	'Dada Jasmine',	201);
insert into Student_tract values(10, 'Christopher Afolabi', 201);
insert into Student_tract values(11, 'Koyejo Dada Kay', 201);
insert into Student_tract values(12, 'Gabby Paul', 201);
insert into Student_tract values(13, 'Daniel Yaw Sarfo', 101);
insert into Student_tract values(14, 'Yusuf Junaid Olamide', 101);
insert into Student_tract values(15, 'Olawuyi Gbolahan Tosin', 101);
insert into Student_tract values(16, 'Junaid Anjolaoluwa', 101);
insert into Student_tract values(17, 'FOLASHADE ATOLAGBE', 301);
insert into Student_tract values(18, 'Lanre Adeyemo', 301);
insert into Student_tract values(19, 'Val Amih Valentine', 301);
insert into Student_tract values(20, 'Nchelem Anita', 301);
insert into Student_tract values(21, 'Temitope Boluwatife', 301);
insert into Student_tract values(22, 'Adeleke Kafayat', 301);
insert into Student_tract values(23, 'Ajibola Majeed', 301);
insert into Student_tract values(24, 'Gbore Oluwaseun Daniel', 301);
insert into Student_tract values(25, 'Ugbong Paul', 301);
insert into Student_tract values(26, 'Sinmisola', 301);

select * from student_tract;

/* I want to create a table named score*/

Create table Score(
id int not null,
studentID int,
by_week	varchar(20),
Attendance_score decimal(5,2),	
Assignment_score decimal (5,2),
primary key (id)
);

/*Inserting rows into the score table*/

insert into Score values(1, 1,	'Week 1',	15,	10);
insert into Score values(2, 1,	'Week 2',	15,	37);
insert into Score values(3, 1,	'Week 3',	15,	30);
insert into Score values(4, 1,	'Week 4',	15,	31);
insert into Score values(5, 1,	'Week 5',	15,	48);
insert into Score values(6, 1,	'Week 6',	15,	null);
insert into Score values(7, 2,	'Week 1',	0,	0);
insert into Score values(8, 2,	'Week 2',	0,	0);
insert into Score values(9, 2,	'Week 3',	0,	0);
insert into Score values(10, 2,	'Week 4',	15,	31);
insert into Score values(11, 2,	'Week 5',	15,	41);
insert into Score values(12, 2,	'Week 6',	10,	null);
insert into Score values(13, 3,	'Week 1',	0,	0);
insert into Score values(14, 3,	'Week 2',	0,	0);
insert into Score values(15, 3,	'Week 3',	10,	19);
insert into Score values(16, 3,	'Week 4',	15,	31);
insert into Score values(17, 3,	'Week 5',	15,	45);
insert into Score values(18,	3,	'Week 6',	15,	null);
insert into Score values(19,	4,	'Week 1',	15,	5);
insert into Score values(20,	4,	'Week 2',	15,	39);
insert into Score values(21,	4,	'Week 3',	15,	28);
insert into Score values(22,	4,	'Week 4',	10,	27);
insert into Score values(23,	4,	'Week 5',	15,	44);
insert into Score values(24,	4,	'Week 6',	15,	null);
insert into Score values(25,	5,	'Week 1',	10,	null);
insert into Score values(26,	5,	'Week 2',	10,	34);
insert into Score values(27,	5,	'Week 3',	10,	0);
insert into Score values(28,	5,	'Week 4',	15,	27);
insert into Score values(29,	5,	'Week 5',	10,	15);
insert into Score values(30,	5,	'Week 6',	10,	null);
insert into Score values(31,	6,	'Week 1',	0,	0);
insert into Score values(32,	6,	'Week 2',	0,	0);
insert into Score values(33,	6,	'Week 3',	0,	0);
insert into Score values(34,	6,	'Week 4',	10,	31);
insert into Score values(35,	6,	'Week 5',	15,	35);
insert into Score values(36,	6,	'Week 6',	15,	null);
insert into Score values(37,	7,	'Week 1',	10,	8);
insert into Score values(38,	7,	'Week 2',	10,	23);
insert into Score values(39,	7,	'Week 3',	15,	5);
insert into Score values(40,	7,	'Week 4',	15,	29);
insert into Score values(41,	7,	'Week 5',	15,	49);
insert into Score values(42,	7,	'Week 6',	15,	null);
insert into Score values(43,	8,	'Week 1',	15,	5);
insert into Score values(44,	8,	'Week 2',	10,	5);
insert into Score values(45,	8,	'Week 3',	10,	4);
insert into Score values(46,	8,	'Week 4',	10,	29);
insert into Score values(47,	8,	'Week 5',	10,	31);
insert into Score values(48,	8,	'Week 6',	15,	null);
insert into Score values(49,	9,	'Week 1',	10,	8);
insert into Score values(50,	9,	'Week 2',	10,	15);
insert into Score values(51,	9,	'Week 3',	15,	19);
insert into Score values(52,	9,	'Week 4',	15,	29);
insert into Score values(53,	9,	'Week 5',	15,	20);
insert into Score values(54,	9,	'Week 6',	15,	null);
insert into Score values(55,	10,	'Week 1',	10,	5);
insert into Score values(56,	10,	'Week 2',	15,	28);
insert into Score values(57,	10,	'Week 3',	15,	27);
insert into Score values(58,	10,	'Week 4',	15,	27);
insert into Score values(59,	10,	'Week 5',	15,	10);
insert into Score values(60,	10,	'Week 6',	5,	null);
insert into Score values(61,	11,	'Week 1',	15,	8);
insert into Score values(62,	11,	'Week 2',	15,	33);
insert into Score values(63,	11,	'Week 3',	10,	20);
insert into Score values(64,	11,	'Week 4',	15,	27);
insert into Score values(65,	11,	'Week 5',	10,	20);
insert into Score values(66,	11,	'Week 6',	10,	null);
insert into Score values(67,	12,	'Week 1',	10,	10);
insert into Score values(68,	12,	'Week 2',	10,	32);
insert into Score values(69,	12,	'Week 3',	10,	0);
insert into Score values(70,	12,	'Week 4',	10,	29);
insert into Score values(71,	12,	'Week 5',	10,	0);
insert into Score values(72,	12,	'Week 6',	5,	null);
insert into Score values(73,	13,	'Week 1',	15,	null);
insert into Score values(74,	13,	'Week 2',	15,	null);
insert into Score values(75,	13,	'Week 3',	15,	40);
insert into Score values(76,	13,	'Week 4',	0,	50);
insert into Score values(77,	13,	'Week 5',	null,	null);
insert into Score values(78,	13,	'Week 6',	5,	null);
insert into Score values(79,	14,	'Week 1',	10,	null);
insert into Score values(80,	14,	'Week 2',	10,	null);
insert into Score values(81,	14,	'Week 3',	10,	0);
insert into Score values(82,	14,	'Week 4',	10,	0);
insert into Score values(83,	14,	'Week 5',	10,	null);
insert into Score values(84,	14,	'Week 6',	null,	null);
insert into Score values(85,	15,	'Week 1',	10,	null);
insert into Score values(86,	15,	'Week 2',	10,	null);
insert into Score values(87,	15,	'Week 3',	15,	35);
insert into Score values(88,	15,	'Week 4',	5,	49);
insert into Score values(89,	15,	'Week 5',	15,	40);
insert into Score values(90,	15,	'Week 6',	5,	null);
insert into Score values(91,	16,	'Week 1',	10,	null);
insert into Score values(92,	16,	'Week 2',	10,	null);
insert into Score values(93,	16,	'Week 3',	10,	20);
insert into Score values(94,	16,	'Week 4',	5,	0);
insert into Score values(95,	16,	'Week 5',	10,	null);
insert into Score values(96,	16,	'Week 6',	null,	null);
insert into Score values(97,	17,	'Week 1',	0,	0);
insert into Score values(98,	17,	'Week 2',	0,	0);
insert into Score values(99,	17,	'Week 3',	0,	0);
insert into Score values(100,	17,	'Week 4',	null,	null);
insert into Score values(101,	17,	'Week 5',	null,	null);
insert into Score values(102,	17,	'Week 6',	null,	null);
insert into Score values(103,	18,	'Week 1',	15,	42.5);
insert into Score values(104,	18,	'Week 2',	15,	46.4);
insert into Score values(105,	18,	'Week 3',	15,	50);
insert into Score values(106,	18,	'Week 4',	15,	46);
insert into Score values(107,	18,	'Week 5',	10,	4);
insert into Score values(108,	18,	'Week 6',	15,	null);
insert into Score values(109,	19,	'Week 1',	15,	42.5);
insert into Score values(110,	19,	'Week 2',	15,	40);
insert into Score values(111,	19,	'Week 3',	15,	null);
insert into Score values(112,	19,	'Week 4',	10,	10);
insert into Score values(113,	19,	'Week 5',	0,	0);
insert into Score values(114,	19,	'Week 6',	0,	null);
insert into Score values(115,	20,	'Week 1',	15,	50);
insert into Score values(116,	20,	'Week 2',	15,	42.9);
insert into Score values(117,	20,	'Week 3',	15,	45);
insert into Score values(118,	20,	'Week 4',	10,	32);
insert into Score values(119,	20,	'Week 5',	15,	31);
insert into Score values(120,	20,	'Week 6',	15,	null);
insert into Score values(121,	21,	'Week 1',	0,	47.5);
insert into Score values(122,	21,	'Week 2',	10,	39.3);
insert into Score values(123,	21,	'Week 3',	15,	5);
insert into Score values(124,	21,	'Week 4',	15,	34);
insert into Score values(125,	21,	'Week 5',	15,	30);
insert into Score values(126,	21,	'Week 6',	15,	null);
insert into Score values(127,	22,	'Week 1',	0,	42.5);
insert into Score values(128,	22,	'Week 2',	10,	40.7);
insert into Score values(129,	22,	'Week 3',	15,	null);
insert into Score values(130,	22,	'Week 4',	15,	42.5);
insert into Score values(131,	22,	'Week 5',	15,	31);
insert into Score values(132,	22,	'Week 6',	15,	null);
insert into Score values(133,	23,	'Week 1',	15,	45);
insert into Score values(134,	23,	'Week 2',	15,	37.1);
insert into Score values(135,	23,	'Week 3',	15,	null);
insert into Score values(136,	23,	'Week 4',	15,	47.5);
insert into Score values(137,	23,	'Week 5',	10,	45);
insert into Score values(138,	23,	'Week 6',	10,	null);
insert into Score values(139,	24,	'Week 1',	15,	45);
insert into Score values(140,	24,	'Week 2',	15,	17.9);
insert into Score values(141,	24,	'Week 3',	15,	null);
insert into Score values(142,	24,	'Week 4',	15,	30.5);
insert into Score values(143,	24,	'Week 5',	15,	42);
insert into Score values(144,	24,	'Week 6',	5,	null);
insert into Score values(145,	25,	'Week 1',	15,	45);
insert into Score values(146,	25,	'Week 2',	15,	42.9);
insert into Score values(147,	25,	'Week 3',	15,	50);
insert into Score values(148,	25,	'Week 4',	15,	45);
insert into Score values(149,	25,	'Week 5',	15,	28.5);
insert into Score values(150,	25,	'Week 6',	15,	null);
insert into Score values(151,	26,	'Week 1',	0,	null);
insert into Score values(152,	26,	'Week 2',	0,	null);
insert into Score values(153,	26,	'Week 3',	0,	null);
insert into Score values(154,	26,	'Week 4',	10,	null);
insert into Score values(155,	26,	'Week 5',	0,	null);
insert into Score values(156,	26,	'Week 6',	10,	null);

select count (*) from score;
select * from score;

/* I want to create a table named Student details*/

Create table students_details(
id int not null,
Gender char not null,
Age int,
Discipline varchar (255),	
current_group int,	
Institution_attended varchar (255),
state varchar (255),
religion varchar (255),	
Nationality	varchar (255),
enrollment_date Datetime,
instructor_name_id	int,
Instructor_rating decimal(10,2),
primary key (id)
);

/*Inserting rows into the Students_details table*/

insert into students_details values(1, 'F', 33,	'Mechanical Engineering', 1, 'University Of Ibadan', 'LAGOS',
'Christian', 'Nigeria',	'2022/05/18',	2,	10);
insert into students_details values(2,	'M',	30,	'Computer science',	1,	'Alumnus FUTA',	'ABUJA',
'Christian', 'Nigeria',	'2022/6/6', 2,	7);
insert into students_details values(3, 	'M',	24,	'Quantity Surveying', 	3, 'Yaba College of Technology', 'LAGOS',
'Christian', 'Nigeria',	'2022/6/3',	'2',	7);
insert into students_details values(7, 'F',	29,	'Public Health',  	2, 'Unilorin',  'JIGAWA',
'Christian',	'Nigeria',	'2022/5/16',	2,	9.5);
insert into students_details values(10, 'M',	22,	'Agricultural biochemistry and nutrition', 	2, 
'University of Ibadan',	'OYO',	'Christian', 	'Nigeria',	'5/23/2022',	2,	10);
insert into students_details values(11,	 'M',	25,	'Computer Science',	1,	'Alumnus FUTA',	'OGUN',
'Christian',	'Nigeria',	'5/23/2022',	2,	8);
insert into students_details values(15,	'M',	29,	'Data Science',	2, 'Zacrac school',	'KWARA',
'Christian',	'Nigeria',	'6/1/2022',	1,	8);
insert into students_details values(16,	'F', 32, 'Entrepreneurship and Business Management', 1, 
'National open University',	'OYO',	'Muslim',	'Nigeria',	'5/6/2022',	1,	10);
insert into students_details values(21,	'F', 25, 'Mechanical Engineering',	2, 'Unilorin', 	'OSUN',
'Christian', 'Nigeria',	'5/30/2022',	3, 9);
insert into students_details values(22,	'F', 27, 'Mechanical Engineering',	1, 'Unilorin', 'KWARA',
'Muslim',	'Nigeria',	'5/30/2022',	3,	10);
insert into students_details values(24,	'M', 28, 'Accounting',	1, 'Adekunle Ajasin University Akungba',	'ONDO',	
'Christian', 'Nigeria',	'5/16/2022',	3,	8);
insert into students_details values(26,	'F',	37,	'Economics/administration',	3,	'Sinmisola Onabowu', 'LAGOS',
'Christian', 'Nigeria',	'5/16/2022',	3,	7);
insert into students_details values(13,	'M',	36,	'Civil Engineering', 	2,	'Daniel Yaw Sarfo', 	'TEMA/GREATER ACCRA',
'Christian', 'Ghanian',	'7/16/2022',	1,	9);
insert into students_details values(9,	'F',	24,	'Building Engineering', 	1,	'University of Lagos',
'LAGOS',	'Christian', 	'Nigerian',	'5/1/2022',	2,	9);
insert into students_details values(8,	'F', '24',	'Pure and applied physics',	2,	'Ladoke Akintola University of Technology',
'KWARA',	'Christian',	'Nigerian',	'5/5/2022',	2,	8);
insert into students_details values(25,	'M',	33,	'Computer science', 	1,	'Federal polytechnic Nasarawa', 'ABUJA',
'NA',	'Nigerian',	'5/18/2022',	3,	10);
insert into students_details values(18,	'M', 23,	'Economics',	2,	'Federal University Lafia',	'KWARA',	'Christian',
'Nigerian',	'3/29/2022',	3,	9);

select * from students_details
select * from Tract
select * from Score
select * from Student_tract
select * from Instructors_Name

/*Solution*/
/*1. Print out a table for the top 10 best students in the incubator program so far (use total weekly score). */

select top 10 st.Student_Name, t.Name tract, sum(coalesce (s.attendance_score,0) + coalesce (s.assignment_score,0)) as total_score 
from Score s
join Student_tract st
on s.studentID = st.id
join tract t
on t.tract_id = st.tract
group by st.Student_Name, t.Name
order by total_score desc;

/* 2. Do a comparative analysis of students� performance across the three classes (beautiful
and well-interpreted visualization is required)*/

select t.name tract, avg(isnull (s.attendance_score,0) + isnull (s.assignment_score,0)) as total_score
from score s
join Student_tract st
on s.studentID = st.id
join tract t
on t.tract_id = st.tract
group by t.name;

/*3. Visualize the performance of students based on their educational field or discipline*/

select sd.Discipline, avg(isnull (s.attendance_score,0) + isnull (s.assignment_score,0)) as total_score
from score s
join students_details sd
on s.studentID = sd.id
group by sd.Discipline
order by total_score desc;

/*4. Visualize the performance of students based on their group in class.*/

select sd.current_group, t.name, avg(isnull (s.attendance_score,0) + isnull (s.assignment_score,0)) as total_score
from score s
join students_details sd
on s.studentID = sd.id
join Student_tract st
on st.id = sd.id
join tract t
on t.tract_id = st.tract
GROUP BY sd.current_group, t.name
order by sd.current_group;

/* 5 Visualize the performance of students based on their state/region*/

select sd.state, avg(isnull (s.attendance_score,0) + isnull (s.assignment_score,0)) as total_score
from score s
join students_details sd
on s.studentID = sd.id
group by sd.state
order by total_score desc;

/* 6 Filter by Age, and compare the performance of students less than or equal to 25 years
and those greater than 25 years (Visualization is also required)*/

select case when sd.age <= 25 then 'less or equal 25'
else 'greater 25' end as Age,
avg(isnull (s.attendance_score,0) + isnull (s.assignment_score,0)) as total_score
from score s
join students_details sd
on s.studentID = sd.id
group by case when sd.age <= 25 then 'less or equal 25'
else 'greater 25' end;

/*7 Produce a table showing each student�s name and their enrollment date.*/

Select st.Student_Name, DATENAME(day, sd.enrollment_date) as day, DATENAME(MONTH, sd.enrollment_date) as Month
from Student_tract st
join students_details sd
on st.id = sd.id
order by DATENAME(MONTH, sd.enrollment_date), DATENAME(day, sd.enrollment_date) desc

/*8 Produce a plot showing instructors� ratings on class progress.*/

select n.name, avg(sd.Instructor_rating) Instuctor_rating
from students_details sd
join Instructors_Name n
on sd.instructor_name_id = n.id
group by n.name;

/* 9. Produce students� that shows students� performance in class relative to their
attendance score.*/

select t.Name tract, st.Student_Name, sum(isnull (s.attendance_score,0)) as attendance , 
sum(isnull (s.attendance_score,0) + isnull (s.assignment_score,0)) as total_score
from score s
join Student_tract st
on s.studentID = st.id
join tract t
on t.tract_id = st.tract
GROUP BY st.Student_Name, t.name
order by t.Name, attendance desc

/* 10. For each class, obtain the week with the lowest grades (total weekly performance for
all students in each traction) and the week with the highest grade (total weekly
performance for all students in each traction).*/

select t.name tract,s.by_week, min(isnull (s.attendance_score,0) + isnull (s.assignment_score,0)) as total_score
from score s
join Student_tract st
on s.studentID = st.id
join tract t
on t.tract_id = st.tract
group by t.name, s.by_week;

select t.name tract,s.by_week, max(isnull (s.attendance_score,0) + isnull (s.assignment_score,0)) as total_score
from score s
join Student_tract st
on s.studentID = st.id
join tract t
on t.tract_id = st.tract
group by t.name, s.by_week;